# ConsentX for Joomla

**Cookie consent & CMP — GDPR, CCPA, DPDPA. 1-click connect.**

`plg_system_consentx` is a Joomla **4 & 5** system plugin that installs the
ConsentX cookie-consent banner on your site with a single click. Connect your
ConsentX account from the plugin's settings and the consent widget loads itself
on every front-end page — no code to copy, no manual domain entry.

- Author: **ConsentX** · <https://consentx.io>
- License: **GPL-2.0-or-later**
- Version: **1.0.0**
- Requires: Joomla 4.0+ / 5.x · PHP **8.1+**

---

## What it does

1. **1-click Connect (Model A handshake).** From *System → Manage → Plugins →
   System - ConsentX*, click **Connect to ConsentX**. The plugin generates a
   CSRF `state`, stores it in your session, and redirects you to
   `https://app.consentx.io/admin/connect`. After you approve, ConsentX
   auto-creates a Website for your domain, **registers the domain in the
   allowlist**, mints a scoped API token, and redirects back to an
   administrator URL on your own host carrying `site_key`, `token` and the
   echoed `state`. The plugin verifies the state (constant-time) and stores the
   `site_key` + `token` into its own params.

2. **Embed injection.** On `onBeforeCompileHead` (front end only), the plugin
   injects, as early as possible in `<head>`:

   ```html
   <script type="module" src="https://app.consentx.io/api/SITE_KEY/embed.js"></script>
   ```

   `embed.js` is self-contained: it injects the scoped widget CSS + JS, appends
   the `#consentx-cookie-consent` mount to `<body>`, reads geo/config from the
   server, renders the banner, and emits the `cx:consent` event
   (`detail.granted` = array of granted category slugs). It also exposes
   `window.ConsentX` for re-opening preferences.

3. **Google Consent Mode v2 (optional, on by default).** Prints the
   denied-by-default `gtag('consent','default',…)` stub before any analytics
   tag fires. The ConsentX widget emits the matching `consent','update'` calls
   on the visitor's choice.

---

## Installation

1. Zip the contents of this folder so `consentx.xml` is at the **root** of the
   archive (see *Packaging* below), or install the pre-built
   `plg_system_consentx-1.0.0.zip`.
2. In Joomla admin: **System → Install → Extensions → Upload Package File** and
   drop the zip.
3. **System → Manage → Plugins**, search `ConsentX`, open **System - ConsentX**
   and set the plugin **Status: Enabled**.
4. Click **Connect to ConsentX** and approve. Done — the banner is live.

### Manual (no-Connect) setup

If you prefer not to use the redirect handshake, paste your **Site key** (from
*ConsentX dashboard → Websites → your site*) into the **Site key (manual)**
field and save. You must also add this exact domain to the property in the
ConsentX dashboard so the embed is allowlisted.

### Staging / self-hosted ConsentX

Override **ConsentX app host** in the plugin params (default
`https://app.consentx.io`). Both the Connect redirect and the embed URL follow
this value.

---

## Packaging

From this directory, build an installable package whose manifest sits at the
archive root:

```bash
cd cms/joomla
zip -r ../../plg_system_consentx-1.0.0.zip . -x '*.DS_Store'
```

The manifest's `<files>`, `<media>` and `<languages>` sections declare every
shipped path, so Joomla copies `src/` (namespaced classes), `services/` (DI
provider), `tmpl/`, language `.ini` files and the brand logo into the right
places.

---

## How Connect works (security notes)

- `redirect_uri` is always an `administrator/index.php` URL **on your own host**
  (`scheme + host` equals the bare `domain` we send), so ConsentX never leaks a
  token to a foreign origin.
- The `state` is 160 bits of `random_bytes`, stored server-side in the Joomla
  session and compared with `hash_equals()` on return.
- Connect / disconnect actions require a back-end user with `core.admin`;
  disconnect additionally requires a valid Joomla form token.
- `site_key` is stored via `filter="cmd"`; all rendered output is escaped with
  `htmlspecialchars()` / Joomla `Text`.

---

## File map

| Path | Purpose |
|------|---------|
| `consentx.xml` | Extension manifest (metadata, files, params form). |
| `services/provider.php` | DI service provider (Joomla 4/5 plugin bootstrap). |
| `src/Extension/Consentx.php` | The plugin: embed injection + Connect handshake. |
| `src/Field/ConsentxconnectField.php` | Branded connect panel in the params screen. |
| `language/en-GB/*.ini` | UI + system language strings. |
| `media/plg_system_consentx/images/` | Brandbook logos (`consentx-logo.svg`). |

---

## Changelog

See [CHANGELOG.md](CHANGELOG.md).
