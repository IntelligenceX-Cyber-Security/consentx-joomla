# Changelog

All notable changes to the ConsentX Joomla system plugin are documented here.
This project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Fixed
- Admin connect panel showed a broken logo: the relative image path included
  `images/`, which Joomla adds itself, so it resolved to nothing (`src=""`).
- Front-end launcher rendered as a square under Bootstrap-based templates
  (Cassiopeia's `button{border-radius:0}` beats the embed's layered
  `.bcc-rounded-full`). New `media/css/consentx-launcher.css` restores the circle.

## [1.0.0] — 2026-06-20

### Added
- Initial release of `plg_system_consentx` for Joomla 4 & 5 (PHP 8.1+).
- 1-click Connect handshake (Model A) against `https://app.consentx.io/admin/connect`
  with CSRF `state` verification and automatic storage of `site_key` + scoped
  `token` into the plugin params.
- Embed injection on `onBeforeCompileHead` (front end): module script
  `/api/SITE_KEY/embed.js` added as early as possible in `<head>`.
- Optional Google Consent Mode v2 denied-by-default stub.
- Branded connect panel (brandbook logo + connection status + Connect /
  Disconnect) as a custom params field.
- Manual site-key fallback and overridable ConsentX app host for staging.
- en-GB language files, index.html guards, GPL-2.0-or-later license.
