<?php

/**
 * ConsentX system plugin service provider.
 *
 * Wires the namespaced plugin into Joomla's dependency-injection container the
 * way Joomla 4/5 require for `type="plugin"` extensions. Without this file the
 * plugin would never be instantiated on a modern Joomla install.
 *
 * @package     ConsentX.Plugin
 * @subpackage  System.consentx
 * @copyright   Copyright (C) ConsentX. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

\defined('_JEXEC') or die;

use ConsentX\Plugin\System\Consentx\Extension\Consentx;
use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use Joomla\Event\DispatcherInterface;

return new class () implements ServiceProviderInterface {
    /**
     * Registers the service provider with a DI container.
     *
     * @param   Container  $container  The DI container.
     *
     * @return  void
     */
    public function register(Container $container): void
    {
        $container->set(
            PluginInterface::class,
            function (Container $container) {
                $config  = (array) PluginHelper::getPlugin('system', 'consentx');
                $subject = $container->get(DispatcherInterface::class);

                $plugin = new Consentx($subject, $config);
                $plugin->setApplication(Factory::getApplication());
                $plugin->setDatabase($container->get(\Joomla\Database\DatabaseInterface::class));

                return $plugin;
            }
        );
    }
};
