<?php

/**
 * ConsentX — Joomla 4/5 system plugin.
 *
 * Responsibilities:
 *  1. Inject the ConsentX embed (`/api/<site_key>/embed.js`) into the front-end
 *     <head> as early as possible, plus the optional Google Consent Mode v2
 *     denied-by-default stub.
 *  2. Run the 1-click Connect handshake (Model A) against app.consentx.io:
 *     start -> redirect to /admin/connect, callback -> verify state + store
 *     site_key/token back into this plugin's params.
 *
 * The ConsentX server auto-registers this site's domain in the allowlist during
 * approval, so the banner works the instant the key is stored — no manual entry.
 *
 * @package     ConsentX.Plugin
 * @subpackage  System.consentx
 * @copyright   Copyright (C) ConsentX. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace ConsentX\Plugin\System\Consentx\Extension;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Table\Table;
use Joomla\CMS\Uri\Uri;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Event\SubscriberInterface;

\defined('_JEXEC') or die;

/**
 * ConsentX system plugin.
 */
final class Consentx extends CMSPlugin implements SubscriberInterface, DatabaseAwareInterface
{
    use DatabaseAwareTrait;

    /**
     * Default ConsentX application host (scheme, no trailing slash). Overridable
     * via the plugin's "app_url" param for staging / self-hosted installs.
     *
     * @var string
     */
    private const DEFAULT_APP_URL = 'https://app.consentx.io';

    /**
     * The connect client id this platform is allowlisted as, server-side.
     *
     * @var string
     */
    private const CONNECT_CLIENT = 'joomla';

    /**
     * Session key under which the CSRF state is parked between start + callback.
     *
     * @var string
     */
    private const STATE_KEY = 'consentx.connect.state';

    /**
     * Load this plugin's language strings automatically.
     *
     * @var boolean
     */
    protected $autoloadLanguage = true;

    /**
     * Returns the events this subscriber listens to.
     *
     * @return  array<string, string>
     */
    public static function getSubscribedEvents(): array
    {
        return [
            'onAfterRoute'         => 'onAfterRoute',
            'onBeforeCompileHead'  => 'onBeforeCompileHead',
        ];
    }

    /**
     * Intercept the Connect start + callback requests in the administrator app.
     *
     * We use a custom `consentx_task` query parameter on any administrator URL so
     * the redirect_uri host always equals the site host (required by ConsentX).
     *
     * @return  void
     */
    public function onAfterRoute(): void
    {
        $app = $this->getApplication();

        if (!$app->isClient('administrator')) {
            return;
        }

        $task = $app->getInput()->getCmd('consentx_task', '');

        if ($task === '') {
            return;
        }

        // Only logged-in back-end users with config rights may drive the handshake.
        if (!$this->currentUserCanManage()) {
            $app->enqueueMessage(Text::_('PLG_SYSTEM_CONSENTX_ERR_NO_PERMISSION'), 'error');
            $this->redirectToSettings();

            return;
        }

        switch ($task) {
            case 'connect':
                $this->connectStart();
                break;

            case 'callback':
                $this->connectCallback();
                break;

            case 'disconnect':
                $this->disconnect();
                break;
        }
    }

    /**
     * Inject the ConsentX embed (+ optional Consent Mode defaults) into <head>
     * on every front-end page once a site key is connected.
     *
     * @return  void
     */
    public function onBeforeCompileHead(): void
    {
        $app = $this->getApplication();

        if (!$app->isClient('site')) {
            return;
        }

        $siteKey = $this->siteKey();

        if ($siteKey === '') {
            return;
        }

        $document = $app->getDocument();

        // 1. Consent Mode v2 denied-by-default — MUST print before any analytics
        //    tag, so we add it as the first custom head string at high priority.
        if ((int) $this->params->get('consent_mode', 1) === 1) {
            $document->addCustomTag($this->consentModeStub());
        }

        // 2. The self-contained ConsentX embed module. It appends the
        //    #consentx-cookie-consent mount to <body> and renders the banner.
        $src = $this->appUrl() . '/api/' . rawurlencode($siteKey) . '/embed.js';

        // In Joomla 4/5 Document::addScript($url, $options, $attribs): HTML
        // attributes (type/async/defer) belong in the THIRD argument. The embed
        // contract requires type="module".
        $document->addScript(
            $src,
            [],
            ['type' => 'module']
        );

        // 3. Keep the embed's round launcher button round under Joomla
        //    templates (see media/css/consentx-launcher.css).
        $document->getWebAssetManager()->registerAndUseStyle(
            'plg_system_consentx.launcher',
            'plg_system_consentx/consentx-launcher.css',
            ['version' => 'auto']
        );
    }

    /**
     * Step 1 — generate a CSRF state, store it in the session, and redirect the
     * admin's browser to the ConsentX authorize screen.
     *
     * @return  void
     */
    private function connectStart(): void
    {
        $session = $this->getApplication()->getSession();

        $state = bin2hex(random_bytes(20));
        $session->set(self::STATE_KEY, $state);

        // redirect_uri MUST be an admin URL whose host equals the site domain.
        $callback = $this->adminBaseUri() . '?option=com_plugins&consentx_task=callback';

        $query = [
            'client'       => self::CONNECT_CLIENT,
            'redirect_uri' => $callback,
            'state'        => $state,
            'domain'       => $this->siteHost(),
            'site_name'    => $this->siteName(),
        ];

        // http_build_query encodes each value exactly once (RFC 3986). Do NOT
        // pre-encode redirect_uri — double-encoding fails ConsentX validation.
        $url = $this->appUrl() . '/admin/connect?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);

        $this->getApplication()->redirect($url);
    }

    /**
     * Step 2/3 — ConsentX redirects back with ?site_key=&token=&state=. Verify
     * the round-tripped state (constant-time), then persist the credentials.
     *
     * @return  void
     */
    private function connectCallback(): void
    {
        $app     = $this->getApplication();
        $input   = $app->getInput();
        $session = $app->getSession();

        $expected = (string) $session->get(self::STATE_KEY, '');
        $session->clear(self::STATE_KEY);

        $got     = $input->getString('state', '');
        $siteKey = $input->getCmd('site_key', '');
        $token   = $input->get('token', '', 'string');

        if ($expected === '' || !hash_equals($expected, $got)) {
            $app->enqueueMessage(Text::_('PLG_SYSTEM_CONSENTX_ERR_STATE_MISMATCH'), 'error');
            $this->redirectToSettings();

            return;
        }

        if ($siteKey === '') {
            $app->enqueueMessage(Text::_('PLG_SYSTEM_CONSENTX_ERR_NO_KEY'), 'error');
            $this->redirectToSettings();

            return;
        }

        $this->storeParams(
            [
                'site_key' => $siteKey,
                'token'    => $token,
            ]
        );

        $app->enqueueMessage(Text::_('PLG_SYSTEM_CONSENTX_MSG_CONNECTED'), 'message');
        $this->redirectToSettings();
    }

    /**
     * Clear the stored site_key/token locally. The scoped token can also be
     * revoked from the ConsentX admin -> API Tokens.
     *
     * @return  void
     */
    private function disconnect(): void
    {
        // CSRF guard on the disconnect action (it mutates stored params). The
        // disconnect link in the connect panel carries Session::getFormToken().
        if (!Session::checkToken('get')) {
            $this->getApplication()->enqueueMessage(Text::_('JINVALID_TOKEN'), 'error');
            $this->redirectToSettings();

            return;
        }

        $this->storeParams(
            [
                'site_key' => '',
                'token'    => '',
            ]
        );

        $this->getApplication()->enqueueMessage(Text::_('PLG_SYSTEM_CONSENTX_MSG_DISCONNECTED'), 'message');
        $this->redirectToSettings();
    }

    /**
     * Merge a partial set of values into this plugin's stored params and write
     * the extension row back to #__extensions.
     *
     * @param   array<string, mixed>  $partial  Keys to update.
     *
     * @return  void
     */
    private function storeParams(array $partial): void
    {
        foreach ($partial as $key => $value) {
            $this->params->set($key, $value);
        }

        /** @var \Joomla\CMS\Table\Extension $table */
        $table = Table::getInstance('extension');

        $db    = $this->getDatabase();
        $query = $db->getQuery(true)
            ->select($db->quoteName('extension_id'))
            ->from($db->quoteName('#__extensions'))
            ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
            ->where($db->quoteName('folder') . ' = ' . $db->quote('system'))
            ->where($db->quoteName('element') . ' = ' . $db->quote('consentx'));

        $db->setQuery($query);
        $extensionId = (int) $db->loadResult();

        if ($extensionId === 0 || !$table->load($extensionId)) {
            $this->getApplication()->enqueueMessage(Text::_('PLG_SYSTEM_CONSENTX_ERR_STORE_FAILED'), 'error');

            return;
        }

        $table->params = $this->params->toString();

        if (!$table->store()) {
            $this->getApplication()->enqueueMessage(Text::_('PLG_SYSTEM_CONSENTX_ERR_STORE_FAILED'), 'error');
        }
    }

    /**
     * The Google Consent Mode v2 denied-by-default stub.
     *
     * @return  string
     */
    private function consentModeStub(): string
    {
        return <<<'HTML'
<!-- ConsentX: Google Consent Mode v2 defaults -->
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('consent', 'default', {
	ad_storage: 'denied',
	analytics_storage: 'denied',
	ad_user_data: 'denied',
	ad_personalization: 'denied',
	functionality_storage: 'denied',
	personalization_storage: 'denied',
	security_storage: 'granted',
	wait_for_update: 500
});
</script>
HTML;
    }

    /**
     * The connected site key, trimmed.
     *
     * @return  string
     */
    private function siteKey(): string
    {
        return trim((string) $this->params->get('site_key', ''));
    }

    /**
     * The ConsentX app host (scheme, no trailing slash), from params or default.
     *
     * @return  string
     */
    private function appUrl(): string
    {
        $url = trim((string) $this->params->get('app_url', self::DEFAULT_APP_URL));

        if ($url === '') {
            $url = self::DEFAULT_APP_URL;
        }

        return self::normalizeAppUrl($url);
    }

    /**
     * Normalise a ConsentX app host. The Connect handshake and the embed loader
     * live on the `app.` subdomain, so the marketing apex (`consentx.io`) and
     * `www.consentx.io` — which return 404 for `/admin/connect` and `/api/...`
     * — are rewritten to the canonical app host. Any other host (staging or a
     * self-hosted instance) is passed through untouched, sans trailing slash.
     *
     * @param   string  $url  The raw host value from params.
     *
     * @return  string
     */
    private static function normalizeAppUrl(string $url): string
    {
        $url = rtrim(trim($url), '/');

        if ($url === '') {
            return self::DEFAULT_APP_URL;
        }

        // Ensure a scheme so parse_url() can read the host reliably.
        $probe = preg_match('~^https?://~i', $url) ? $url : 'https://' . $url;
        $host  = strtolower((string) parse_url($probe, PHP_URL_HOST));

        if ($host === 'consentx.io' || $host === 'www.consentx.io') {
            return self::DEFAULT_APP_URL;
        }

        return $url;
    }

    /**
     * Bare site host (no scheme / www / port) — what ConsentX allowlists.
     *
     * @return  string
     */
    private function siteHost(): string
    {
        $host = strtolower((string) Uri::getInstance(Uri::root())->getHost());

        return preg_replace('/^www\./', '', $host) ?? $host;
    }

    /**
     * Human-readable site name for the ConsentX approve screen.
     *
     * @return  string
     */
    private function siteName(): string
    {
        return (string) ($this->getApplication()->get('sitename') ?: $this->siteHost());
    }

    /**
     * Absolute administrator base URI on the merchant's own host (its scheme +
     * host must equal the `domain` we send so ConsentX accepts the redirect_uri).
     *
     * @return  string
     */
    private function adminBaseUri(): string
    {
        $uri = Uri::getInstance(Uri::root());

        return $uri->toString(['scheme', 'host', 'port']) . Uri::base(true) . '/index.php';
    }

    /**
     * Whether the current back-end user may manage this configuration.
     *
     * @return  boolean
     */
    private function currentUserCanManage(): bool
    {
        $user = $this->getApplication()->getIdentity();

        return $user !== null && $user->authorise('core.admin');
    }

    /**
     * Redirect the admin back to this plugin's edit screen.
     *
     * @return  void
     */
    private function redirectToSettings(): void
    {
        $extensionId = $this->extensionId();

        if ($extensionId > 0) {
            $url = 'index.php?option=com_plugins&task=plugin.edit&extension_id=' . $extensionId;
        } else {
            $url = 'index.php?option=com_plugins&view=plugins&filter[folder]=system&filter[search]=consentx';
        }

        $this->getApplication()->redirect(Route::_($url, false));
    }

    /**
     * Resolve this plugin's extension_id (for deep-linking back to its editor).
     *
     * @return  integer
     */
    private function extensionId(): int
    {
        $db    = $this->getDatabase();
        $query = $db->getQuery(true)
            ->select($db->quoteName('extension_id'))
            ->from($db->quoteName('#__extensions'))
            ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
            ->where($db->quoteName('folder') . ' = ' . $db->quote('system'))
            ->where($db->quoteName('element') . ' = ' . $db->quote('consentx'));

        $db->setQuery($query);

        return (int) $db->loadResult();
    }
}
