<?php

/**
 * Custom form field that renders the ConsentX connection panel inside the
 * plugin's parameters: the brandbook logo header, live connection status, and
 * the 1-click Connect / Disconnect buttons.
 *
 * @package     ConsentX.Plugin
 * @subpackage  System.consentx
 * @copyright   Copyright (C) ConsentX. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace ConsentX\Plugin\System\Consentx\Field;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormField;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;

\defined('_JEXEC') or die;

/**
 * Renders the ConsentX connect panel. Read-only display field (no input value).
 */
class ConsentxconnectField extends FormField
{
    /**
     * The field type.
     *
     * @var string
     */
    protected $type = 'Consentxconnect';

    /**
     * The canonical ConsentX app host. Kept in sync with the plugin's own
     * DEFAULT_APP_URL constant.
     *
     * @var string
     */
    private const DEFAULT_APP_URL = 'https://app.consentx.io';

    /**
     * Hide the label column; the panel is full-width.
     *
     * @return  string
     */
    protected function getLabel()
    {
        return '';
    }

    /**
     * Normalise a ConsentX app host for the panel links. The dashboard, loader
     * and register URLs all live on the `app.` subdomain, so the marketing apex
     * (`consentx.io`) and `www.consentx.io` are rewritten to the canonical app
     * host. Any other host (staging / self-hosted) passes through untouched.
     *
     * @param   string  $url  The raw host value from the bound form.
     *
     * @return  string
     */
    private static function normalizeAppUrl(string $url): string
    {
        $url = rtrim(trim($url), '/');

        if ($url === '') {
            return self::DEFAULT_APP_URL;
        }

        $probe = preg_match('~^https?://~i', $url) ? $url : 'https://' . $url;
        $host  = strtolower((string) parse_url($probe, PHP_URL_HOST));

        if ($host === 'consentx.io' || $host === 'www.consentx.io') {
            return self::DEFAULT_APP_URL;
        }

        return $url;
    }

    /**
     * Build the panel markup.
     *
     * @return  string
     */
    protected function getInput()
    {
        $app = Factory::getApplication();

        // Sibling param values come through the bound form data.
        $siteKey   = trim((string) $this->form->getValue('site_key', 'params', ''));
        $appUrl    = self::normalizeAppUrl((string) $this->form->getValue('app_url', 'params', 'https://app.consentx.io'));
        $connected = $siteKey !== '';

        // Relative image paths are "<extension>/<file>": Joomla inserts the
        // `images` folder itself and resolves this to
        // media/plg_system_consentx/images/consentx-logo.svg. Adding `images/`
        // here would make it look in .../images/images/ and render src="".
        $logo = HTMLHelper::_(
            'image',
            'plg_system_consentx/consentx-logo.svg',
            'ConsentX',
            ['style' => 'height:40px;width:auto;display:block;'],
            true,
            0
        );

        // Admin URL whose host == site host; carries our intercepted task param.
        $base       = Uri::base();
        $connectUrl = $base . 'index.php?option=com_plugins&consentx_task=connect';
        $token      = Session::getFormToken();
        $disconnect = $base . 'index.php?option=com_plugins&consentx_task=disconnect&' . $token . '=1';

        $dashboardUrl = $appUrl . '/admin/websites';
        $registerUrl  = $appUrl . '/auth/register';
        $loaderUrl    = $appUrl . '/api/' . rawurlencode($siteKey) . '/embed.js';

        $tagline = Text::_('PLG_SYSTEM_CONSENTX_TAGLINE');

        $html = [];

        $html[] = '<div class="consentx-panel card" style="max-width:760px;border:1px solid #dde1e6;border-radius:10px;padding:20px;margin-bottom:18px;background:#fff;">';

        // Brand header.
        $html[] = '<div style="display:flex;align-items:center;gap:14px;border-bottom:1px solid #eef0f3;padding-bottom:14px;margin-bottom:16px;">';
        $html[] = $logo;
        $html[] = '<span style="color:#5a6675;font-size:13px;">' . htmlspecialchars($tagline, ENT_QUOTES, 'UTF-8') . '</span>';
        $html[] = '</div>';

        if ($connected) {
            $html[] = '<h3 style="margin:0 0 6px;">' . Text::_('PLG_SYSTEM_CONSENTX_STATUS_CONNECTED')
                . ' <span style="color:#15a34a;">&#10003;</span></h3>';
            $html[] = '<p style="margin:0 0 4px;">' . Text::_('PLG_SYSTEM_CONSENTX_LABEL_SITE_KEY')
                . ' <code>' . htmlspecialchars($siteKey, ENT_QUOTES, 'UTF-8') . '</code></p>';
            $html[] = '<p style="color:#5a6675;margin:0 0 14px;">' . Text::_('PLG_SYSTEM_CONSENTX_CONNECTED_HELP') . '</p>';

            $html[] = '<div style="display:flex;flex-wrap:wrap;gap:8px;">';
            $html[] = '<a class="btn btn-primary" target="_blank" rel="noopener" href="'
                . htmlspecialchars($dashboardUrl, ENT_QUOTES, 'UTF-8') . '">'
                . Text::_('PLG_SYSTEM_CONSENTX_BTN_DASHBOARD') . '</a>';
            $html[] = '<a class="btn btn-outline-secondary" target="_blank" rel="noopener" href="'
                . htmlspecialchars($loaderUrl, ENT_QUOTES, 'UTF-8') . '">'
                . Text::_('PLG_SYSTEM_CONSENTX_BTN_LOADER') . '</a>';
            $html[] = '<a class="btn btn-outline-danger" href="'
                . htmlspecialchars($disconnect, ENT_QUOTES, 'UTF-8') . '">'
                . Text::_('PLG_SYSTEM_CONSENTX_BTN_DISCONNECT') . '</a>';
            $html[] = '</div>';
        } else {
            $html[] = '<h3 style="margin:0 0 6px;">' . Text::_('PLG_SYSTEM_CONSENTX_STATUS_NOT_CONNECTED') . '</h3>';
            $html[] = '<p style="color:#5a6675;margin:0 0 14px;">' . Text::_('PLG_SYSTEM_CONSENTX_CONNECT_HELP') . '</p>';

            $html[] = '<div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;">';
            $html[] = '<a class="btn btn-primary btn-lg" href="'
                . htmlspecialchars($connectUrl, ENT_QUOTES, 'UTF-8') . '">'
                . Text::_('PLG_SYSTEM_CONSENTX_BTN_CONNECT') . '</a>';
            $html[] = '<a target="_blank" rel="noopener" href="'
                . htmlspecialchars($registerUrl, ENT_QUOTES, 'UTF-8') . '" style="font-size:13px;">'
                . Text::_('PLG_SYSTEM_CONSENTX_NO_ACCOUNT') . '</a>';
            $html[] = '</div>';
            $html[] = '<p style="color:#8a93a0;font-size:12px;margin-top:12px;">'
                . Text::_('PLG_SYSTEM_CONSENTX_MANUAL_HINT') . '</p>';
        }

        $html[] = '</div>';

        return implode("\n", $html);
    }
}
